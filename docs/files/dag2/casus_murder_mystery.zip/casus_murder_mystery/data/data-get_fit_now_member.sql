-- Dit bestand bevat 19 INSERT-statements: selecteer alles (Ctrl+A, Mac: Cmd+A) en druk Ctrl+Enter.
-- Alleen Ctrl+Enter voert maar één statement uit (het statement waar je cursor in staat).

INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('NL318',65076,'Everette Koepke',20170926,'gold'),
	 ('AOE21',39426,'Noe Locascio',20171005,'regular'),
	 ('2PN28',63823,'Jeromy Heitschmidt',20180215,'silver'),
	 ('0YJ24',80651,'Waneta Wellard',20171206,'gold'),
	 ('3A08L',32858,'Mei Bianchin',20170401,'silver'),
	 ('6W6I2',69510,'Paris Accurso',20170613,'regular'),
	 ('5Y28Y',15218,'Millicent Yessios',20180205,'gold'),
	 ('156A7',79701,'Marcelino Leard',20180428,'silver'),
	 ('A5N3S',24541,'Mary Cameron',20170501,'gold'),
	 ('X0643',15247,'Shondra Ledlow',20170521,'silver');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('8T75D',86040,'Shani Mcclard',20170430,'silver'),
	 ('R440Q',37694,'Jan Louthan',20170606,'silver'),
	 ('R4J4S',13703,'Lien Yasin',20170414,'gold'),
	 ('K055L',60785,'Latisha Larzazs',20170503,'regular'),
	 ('338FV',66842,'Susanne Dubicki',20170719,'gold'),
	 ('401Y4',80191,'Gary Hanohano',20170627,'regular'),
	 ('DEQP8',19108,'Dwight Roussel',20180108,'regular'),
	 ('N7F6U',52425,'Nick Delage',20170709,'silver'),
	 ('Z7Y82',31477,'Rigoberto Hartgrave',20170817,'silver'),
	 ('THJ81',12344,'Thaddeus Modin',20170616,'regular');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('51SWX',92075,'Keshia Llanet',20170812,'regular'),
	 ('4TZ45',61663,'Bebe Heilmann',20180417,'silver'),
	 ('5Y85X',45746,'Frederic Borsellino',20170803,'regular'),
	 ('2Q45D',47693,'Owen Caston',20170102,'silver'),
	 ('E43E8',96742,'Christian Hogue',20171014,'silver'),
	 ('TXNSC',18044,'Roberto Slot',20170510,'silver'),
	 ('1G2F7',90543,'Roger Bowling',20170511,'silver'),
	 ('0862D',62171,'Johana Dayer',20170612,'gold'),
	 ('1G205',31411,'Toshia Sininger',20170125,'silver'),
	 ('6071T',85645,'Bea Fadei',20180223,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('4D5R1',87998,'Richie Zerphey',20170808,'regular'),
	 ('82GA2',20716,'Roslyn Gonzaga',20170809,'gold'),
	 ('W83OD',17742,'Danial Bzhyan',20171127,'silver'),
	 ('12C5R',98098,'Samara Decarolis',20170304,'gold'),
	 ('8AEAE',62617,'Phung Motts',20180205,'gold'),
	 ('T80FG',68244,'Cherilyn Raigosa',20170606,'regular'),
	 ('0CR33',62561,'Noe Elgart',20170627,'gold'),
	 ('4JX11',32828,'Earnest Dambrose',20170831,'gold'),
	 ('GHDP5',78264,'Heath Hosack',20171218,'gold'),
	 ('D8FT1',14297,'Roslyn Ayer',20171022,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('0U51D',17301,'Archie Bardwell',20170505,'regular'),
	 ('355UU',33920,'Brandi Gommer',20170117,'silver'),
	 ('V5260',66908,'Luanne Bhan',20170919,'gold'),
	 ('6K7I8',83198,'Audria Vosburgh',20180309,'gold'),
	 ('KE0FH',60260,'Peggy Cortes',20180420,'silver'),
	 ('133ED',70618,'Marcus Lathan',20171122,'silver'),
	 ('2B01Y',47735,'Tania Kubesh',20170417,'gold'),
	 ('8SJ77',12526,'Fawn Lindemuth',20170820,'regular'),
	 ('7I67C',66010,'Simone Mcglinn',20170802,'gold'),
	 ('0F76P',55951,'Ezekiel Nurnberger',20171222,'regular');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('ZAB1A',82357,'Shenna Valiente',20180307,'regular'),
	 ('W5YVL',33243,'Domonique Ballengee',20171029,'regular'),
	 ('ITWMV',25743,'Elna Reichelderfer',20170123,'gold'),
	 ('44VO2',86834,'Aaron Larcher',20171122,'gold'),
	 ('07QP3',15980,'Hugh Piascik',20171222,'regular'),
	 ('D2KY6',99602,'Joline Hollering',20170220,'gold'),
	 ('5O6SK',36413,'Gordon Sixt',20170513,'silver'),
	 ('NJ876',13989,'Norma Gudroe',20170210,'regular'),
	 ('7788A',73797,'Antone Westgate',20180119,'regular'),
	 ('GKZV7',30221,'Jude Fairbairn',20170108,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('PEL8G',83434,'Jerald Aiola',20171216,'silver'),
	 ('T2JF2',40065,'Ignacio Freistuhler',20170306,'regular'),
	 ('43N05',15804,'Laurel Diab',20170129,'regular'),
	 ('HI1Q5',29185,'Yukiko Vogelzang',20180112,'silver'),
	 ('JQ162',11162,'Dorthy Picardi',20170712,'silver'),
	 ('402DQ',92379,'Lynwood Punter',20170104,'silver'),
	 ('33378',32162,'Olen Bolar',20180324,'regular'),
	 ('1RSYJ',62042,'Clement Gidley',20171016,'gold'),
	 ('31A6U',28007,'Magen Brach',20170425,'regular'),
	 ('7BQKU',24145,'Valda Eacret',20171207,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('UK1F2',28073,'Zackary Cabotage',20170818,'silver'),
	 ('NB10J',65316,'Mitzi Bakerville',20170518,'silver'),
	 ('I827Y',96987,'Larraine Gamel',20170911,'silver'),
	 ('O86WU',68360,'Alex Strohmeier',20170730,'gold'),
	 ('30Y1F',71173,'Detra Hemeyer',20180110,'silver'),
	 ('8G0Z2',71282,'Marquis Stace',20180404,'gold'),
	 ('OBU3O',80489,'Wilma Sinstack',20170207,'regular'),
	 ('I0UIP',49229,'Madge Bernice',20170503,'gold'),
	 ('JY514',98128,'Keith Savary',20170207,'regular'),
	 ('E18IN',64073,'Lyda Mandigo',20180316,'silver');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('3OOJ1',62367,'Concha Fiveash',20180109,'regular'),
	 ('N36I5',83633,'Stuart Moitoza',20171208,'gold'),
	 ('C84S4',80745,'Mervin Eacret',20180108,'gold'),
	 ('B5F34',73608,'George Cali',20171218,'regular'),
	 ('6NAWM',53382,'Myles Marushia',20170710,'regular'),
	 ('71BOE',61721,'Maximo Oliver',20170705,'gold'),
	 ('CGW3X',26187,'Hettie Macreno',20180317,'silver'),
	 ('03487',73490,'Lyman Harshbarger',20170529,'silver'),
	 ('7MRZ6',75743,'Brain Puthoff',20180212,'silver'),
	 ('72H2C',49774,'Grant Stutheit',20180121,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('FA4N5',70985,'September Cappelluti',20171109,'gold'),
	 ('3718M',50049,'Carmine Rodell',20170827,'gold'),
	 ('3F8N0',10319,'Tama Mazy',20171021,'gold'),
	 ('48100',68693,'Ammie Mossbarger',20170726,'silver'),
	 ('K3XEZ',30558,'Roxane Bua',20170710,'regular'),
	 ('0Y6DA',67667,'Araceli Roussin',20170304,'gold'),
	 ('XTE42',55662,'Sarita Bartosh',20170524,'gold'),
	 ('P876D',97206,'Elizebeth Torgersen',20180323,'gold'),
	 ('530Q6',53788,'Dagny Mikez',20180218,'regular'),
	 ('2303S',43058,'Willie Mazzella',20170120,'regular');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('I733Y',46526,'Carolin Orellano',20180325,'silver'),
	 ('AD2A5',17882,'Shaun Smeal',20171020,'regular'),
	 ('F83PZ',16232,'Florencio Hodgman',20171128,'gold'),
	 ('1AE2H',10815,'Adriane Pelligra',20170816,'silver'),
	 ('TQU5U',46224,'Jordan Gough',20180131,'silver'),
	 ('06V71',50993,'Travis Windly',20170812,'gold'),
	 ('7YL50',82468,'Patricia Matskin',20180304,'gold'),
	 ('YD4W4',27287,'Cecil Piraino',20170712,'silver'),
	 ('7A4NF',98747,'Aleen Bergmann',20170703,'silver'),
	 ('J2033',51710,'Hal Funchess',20180328,'silver');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('344VM',13466,'Armando Huie',20171002,'regular'),
	 ('X377L',94492,'Alicia Bernson',20170722,'silver'),
	 ('RXP8M',48557,'Cruz Ewings',20180111,'silver'),
	 ('7OG72',98043,'Cher Rivenbark',20180123,'silver'),
	 ('66Z13',44386,'Reinaldo Rhead',20170517,'gold'),
	 ('CZ1H8',68418,'Roberto Spearmon',20170604,'silver'),
	 ('7U8WH',64192,'Bette Mayon',20170722,'silver'),
	 ('5VE7U',66910,'Jacqui Bonda',20171010,'gold'),
	 ('3DC24',10833,'Queen Radigan',20180320,'gold'),
	 ('6LSTG',83186,'Burton Grippe',20170214,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('551F6',24618,'Lazaro Walterson',20180203,'regular'),
	 ('MYQ6A',99462,'Darren Yahraus',20170712,'silver'),
	 ('J5IO8',44080,'Amberly Somdah',20170902,'gold'),
	 ('TLF67',66160,'Addie Tschirhart',20170521,'regular'),
	 ('76W33',43768,'Layne Burakowski',20180201,'regular'),
	 ('QN47X',53753,'Francisco Harcrow',20171214,'regular'),
	 ('V5M14',79592,'Dirk Malhi',20170626,'regular'),
	 ('77Q7L',10325,'Bruna Sumlin',20170604,'silver'),
	 ('MZQ3U',72585,'Mohammad Kotch',20171109,'silver'),
	 ('72B16',36182,'Tanner Faley',20170825,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('4K76L',19138,'Kimbery Pedaci',20170925,'regular'),
	 ('5VK83',84412,'Olimpia Romanick',20170921,'gold'),
	 ('S702J',92540,'Ladawn Boards',20170201,'regular'),
	 ('X1IYH',35809,'Tu Lipkovitch',20170608,'gold'),
	 ('2P828',38212,'Hershel Alstrom',20170113,'silver'),
	 ('QSD41',73130,'Aurelio Schrage',20170203,'regular'),
	 ('V14R0',83737,'Hosea Kuzyk',20180423,'gold'),
	 ('20U07',21727,'Alvin Fornes',20170815,'silver'),
	 ('0EY7M',78357,'Lisette Husain',20170227,'silver'),
	 ('VHN8M',26473,'Travis Bressler',20170516,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('0WG67',77090,'Delora Vais',20170706,'gold'),
	 ('72244',10615,'Harold Fullmer',20170721,'gold'),
	 ('TY21F',94528,'Terrance Helwig',20170603,'gold'),
	 ('TD7DF',60334,'Faustino Sanmartin',20180404,'silver'),
	 ('1YHL3',32045,'Greg Alwardt',20170503,'gold'),
	 ('O5U57',82818,'Luana Kirstein',20170811,'gold'),
	 ('E0ZJ2',59737,'Hank Staufenberger',20170408,'silver'),
	 ('7MWHJ',31523,'Blossom Crescenzo',20180309,'regular'),
	 ('8I2HW',26467,'Wayne Bonyai',20170222,'silver'),
	 ('R55GR',85724,'Marybeth Ulvan',20170406,'gold');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('2STMK',97486,'Milan Knippers',20170523,'regular'),
	 ('C581L',53262,'Monty Torrico',20170307,'silver'),
	 ('WF7P1',93937,'Isaiah Bhagat',20170625,'regular'),
	 ('MORMA',45428,'Nelly Schumachor',20170203,'regular'),
	 ('48Z38',49550,'Tomas Baisley',20170203,'silver'),
	 ('F3U8A',46617,'Vanna Castillanos',20171105,'gold'),
	 ('NF4S2',15581,'Simon Weisenberg',20180426,'gold'),
	 ('3JP0X',91432,'Herschel Deltora',20170131,'silver'),
	 ('3BRSC',19948,'Taylor Skyes',20180314,'gold'),
	 ('RMX31',99277,'Pia Ruthenberg',20171129,'silver');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('58636',62536,'Harvey Jennkie',20180325,'gold'),
	 ('NB387',21200,'Molly Dolin',20180206,'gold'),
	 ('J4ML1',48466,'Jarred Newenle',20170424,'regular'),
	 ('MN1KI',43801,'Art Kunsman',20180118,'silver'),
	 ('GE5Q8',92736,'Carmen Dimick',20170618,'gold'),
	 ('ALP65',46423,'Angel Diachenko',20170717,'regular'),
	 ('0T622',98782,'Sarina Overpeck',20171109,'gold'),
	 ('8VM1U',70172,'Kurt Laplante',20170524,'silver'),
	 ('5SPT1',63130,'Abe Morefield',20171007,'regular'),
	 ('3S8Z0',12049,'Honey Erbentraut',20171123,'regular');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('BL3KC',24033,'Collene Gulde',20170913,'gold'),
	 ('36646',89559,'Titus Ruan',20180203,'regular'),
	 ('CGQ1A',99037,'Adrienne Fleishman',20170718,'regular'),
	 ('4SC0G',92824,'Kennith Splett',20170731,'silver'),
	 ('4MK73',87882,'Bernard Hardgrove',20170427,'regular'),
	 ('82OO1',83144,'Grant Saurel',20170202,'silver'),
	 ('2111X',36646,'Arlie Braig',20170315,'silver'),
	 ('11ZAK',12107,'Agatha Seddon',20170628,'regular'),
	 ('HM6U8',50106,'Edgar Bamba',20170128,'silver'),
	 ('2V137',41693,'Wendell Dulany',20171219,'silver');
INSERT INTO get_fit_now_member (id,person_id,name,membership_start_date,membership_status) VALUES
	 ('4KB72',79110,'Emile Hege',20170522,'regular'),
	 ('48Z7A',28819,'Joe Germuska',20160305,'gold'),
	 ('48Z55',67318,'Jeremy Bowers',20160101,'gold'),
	 ('90081',16371,'Annabel Miller',20160208,'gold');
